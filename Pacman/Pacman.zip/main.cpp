#include <windows.h>
#include <iostream>

#include "Menu.h"

int main() {
	Menu().print();
	return 0;
}