Names & IDs
Amit Neeman 207388794
Daniella Gordover 316464775

Bonus additions:
1. Color options for any stage in game.
2. Special characters for pacman and ghosts.
3. Pause message when the user press 'ESC' during the game.
4. Special headlines for menu, winner message, game over message, pause message.


