#ifndef _MENU_H_
#define _MENU_H_

class Menu {
public:
	void print();
	void printOptions();
	void printInstructions();
	bool checkIfColored();
};

#endif

